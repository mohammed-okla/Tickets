import React from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { 
  Wallet, 
  QrCode, 
  Ticket, 
  Shield, 
  Globe, 
  ArrowRight, 
  Smartphone,
  CreditCard,
  MapPin,
  Users
} from 'lucide-react'
import { useLanguage } from '@/contexts/LanguageContext'
import { Link } from 'react-router-dom'

const features = [
  {
    icon: Wallet,
    titleKey: 'onboard.step1.title',
    descKey: 'onboard.step1.desc'
  },
  {
    icon: QrCode,
    titleKey: 'onboard.step2.title', 
    descKey: 'onboard.step2.desc'
  },
  {
    icon: Ticket,
    titleKey: 'onboard.step3.title',
    descKey: 'onboard.step3.desc'
  }
]

const stats = [
  { icon: Users, value: '10,000+', labelKey: 'Users' },
  { icon: CreditCard, value: '500K+', labelKey: 'Transactions' },
  { icon: MapPin, value: '5+', labelKey: 'Cities' },
  { icon: Shield, value: '99.9%', labelKey: 'Uptime' }
]

export default function LandingPage() {
  const { t, language, setLanguage } = useLanguage()

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-white">
              <Ticket className="h-5 w-5" />
            </div>
            <h1 className="text-xl font-bold text-primary">{t('app.name')}</h1>
          </div>
          
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLanguage(language === 'en' ? 'ar' : 'en')}
            >
              <Globe className="h-4 w-4 mr-2" />
              {language === 'en' ? 'العربية' : 'English'}
            </Button>
            
            <Link to="/login">
              <Button variant="outline" size="sm">
                {t('auth.login')}
              </Button>
            </Link>
            
            <Link to="/register">
              <Button size="sm">
                {t('auth.register')}
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h2 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-6xl mb-6">
              {t('app.welcome')}
            </h2>
            <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
              {t('app.description')}
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Link to="/register">
                <Button size="lg" className="group">
                  {t('onboard.getStarted')}
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </Button>
              </Link>
              
              <Link to="/login">
                <Button variant="outline" size="lg">
                  {t('auth.login')}
                </Button>
              </Link>
            </div>

            {/* Hero Image/App Preview */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative mx-auto max-w-lg"
            >
              <div className="relative rounded-2xl bg-gradient-to-br from-primary/20 to-purple-400/20 p-8 backdrop-blur-sm">
                <Smartphone className="h-48 w-48 mx-auto text-primary/70" />
                <div className="absolute inset-0 rounded-2xl ring-1 ring-inset ring-gray-900/10" />
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">
              {t('onboard.welcome')}
            </h3>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              {t('app.subtitle')}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={feature.titleKey}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
              >
                <Card className="text-center">
                  <CardHeader>
                    <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                      <feature.icon className="h-8 w-8 text-primary" />
                    </div>
                    <CardTitle className="text-xl">
                      {t(feature.titleKey)}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base">
                      {t(feature.descKey)}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={stat.labelKey}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center"
              >
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                  <stat.icon className="h-6 w-6 text-primary" />
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">
                  {stat.value}
                </div>
                <div className="text-sm text-gray-600">
                  {stat.labelKey}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-white">
        <div className="container mx-auto px-4 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-3xl font-bold mb-4">
              Ready to get started?
            </h3>
            <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
              Join thousands of users who trust Tickets for their digital payments and event tickets.
            </p>
            
            <Link to="/register">
              <Button size="lg" variant="secondary" className="group">
                {t('onboard.getStarted')}
                <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-white">
                <Ticket className="h-5 w-5" />
              </div>
              <h4 className="text-xl font-bold text-primary">{t('app.name')}</h4>
            </div>
            <p className="text-gray-600 mb-4">
              {t('app.subtitle')}
            </p>
            <p className="text-sm text-gray-500">
              © 2024 Tickets. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}